import { Component } from '@angular/core';

@Component({
  selector: 'app-gradient-card-container',
  templateUrl: './gradient-card-container.component.html'
})
export class GradientCardContainerComponent  {

  constructor() { }



}
