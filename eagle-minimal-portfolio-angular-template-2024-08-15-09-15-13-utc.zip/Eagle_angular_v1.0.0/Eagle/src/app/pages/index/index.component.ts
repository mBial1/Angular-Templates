import { Component } from '@angular/core';
import { PortfolioItem } from './index.model';
import { productList } from './data';
import { NgxMasonryOptions } from 'ngx-masonry';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent {
  selectedFilter: string = '';
  public products: PortfolioItem[] = [];
  allproducts!: PortfolioItem[]; // Use the PortfolioItem type

  public myOptions: NgxMasonryOptions = {
    horizontalOrder: true
  };
  
  ngOnInit() {
    this.products = Object.assign([], productList);
    this.allproducts = Object.assign([], productList);
  }

  filterItems(category: string) {
    this.selectedFilter = category
    if (category) {
      this.products = this.allproducts.filter((item: any) => {
        return item.category.includes(category)
      })
    } else {
      this.products = this.allproducts
    }
    console.log('products', this.products)
  }


}