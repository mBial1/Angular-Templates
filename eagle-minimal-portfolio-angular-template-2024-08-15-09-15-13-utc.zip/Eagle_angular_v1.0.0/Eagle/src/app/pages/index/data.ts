
const productList = [

    {
        "category": ["natural", "personal"],
        "image": "assets/images/works/img1.jpg",
        "alt": "member-image",
        "description": "Media, Icons",
        "title": "Open Imagination"
    },
    {
        "category": ["creative ", "personal", "photography"],
        "image": "assets/images/works/img2.jpg",
        "alt": "member-image",
        "description": "Illustrations",
        "title": "Locked Steel Gate"
    },
    {
        "category": ["natural ", "creative"],
        "image": "assets/images/works/img3.jpg",
        "alt": "member-image",
        "description": "Graphics, UI Elements",
        "title": "Mac Sunglasses"
    },
    {
        "category": ["personal ", "photography"],
        "image": "assets/images/works/img5.jpg",
        "alt": "member-image",
        "description": "Icons, Illustrations",
        "title": "Morning Dew"
    },
    {
        "category": ["creative", "photography"],
        "image": "assets/images/works/img6.jpg",
        "alt": "member-image",
        "description": "UI Elements, Media",
        "title": "Console Activity"
    },
    {
        "category": ["natural", "personal"],
        "image": "assets/images/works/img4.jpg",
        "alt": "member-image",
        "description": "Graphics",
        "title": "Sunset Bulb Glow"
    },
    {
        "category": ["natural", "creative"],
        "image": "assets/images/works/img7.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    },
    {
        "category": ["creative ", "photography"],
        "image": "assets/images/works/img8.jpg",
        "alt": "member-image",
        "description": "UI Elements, Media",
        "title": "Console Activity"
    },
    {
        "category": "natural",
        "image": "assets/images/works/img9.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    },
    {
        "category": ["natural", "creative"],
        "image": "assets/images/works/img10.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    },
    {
        "category": ["creative", "natural"],
        "image": "assets/images/works/img2.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    },
    {
        "category": ["natural", "creative"],
        "image": "assets/images/works/img6.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    },
    {
        "category": ["natural", "creative"],
        "image": "assets/images/works/img10.jpg",
        "alt": "member-image",
        "description": "Illustrations, Graphics",
        "title": "Shake It!"
    }
]


export { productList }
