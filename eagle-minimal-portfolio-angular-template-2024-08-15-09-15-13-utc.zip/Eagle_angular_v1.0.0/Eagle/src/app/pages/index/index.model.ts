export class PortfolioItem {
    category?: string;
    type?: string;
    image?: string;
    description?: string;
    title?: string;
    alt?: string;
}