import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgxMasonryModule } from 'ngx-masonry';
// routing
import { PagesRoutingModule } from './pages-routing.module';
import { SharedModule } from '../shared/shared.module';
import { IndexComponent } from './index/index.component';
import { ContactComponent } from './contact/contact.component';
import { BlogComponent } from './blog/blog.component';
import { WorkComponent } from './work/work.component';
import { ServiceComponent } from './service/service.component';
import { AboutComponent } from './about/about.component';
import { BlogSingleComponent } from './blog-single/blog-single.component';
import { WorkDetailComponent } from './work-detail/work-detail.component';

@NgModule({
  declarations: [
    IndexComponent,
    ContactComponent,
    BlogComponent,
    WorkComponent,
    ServiceComponent,
    AboutComponent,
    BlogSingleComponent,
    WorkDetailComponent,

  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    SharedModule,
    NgxMasonryModule
  ]

})
export class PagesModule { }
