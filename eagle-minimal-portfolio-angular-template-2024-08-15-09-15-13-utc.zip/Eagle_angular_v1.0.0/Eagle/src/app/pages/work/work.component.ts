import { Component } from '@angular/core';
import { PortfolioItem } from '../index/index.model';
import { productList } from '../index/data';
import { NgxMasonryOptions } from 'ngx-masonry';

@Component({
  selector: 'app-work',
  templateUrl: './work.component.html',
  styleUrls: ['./work.component.scss']
})
export class WorkComponent {
  selectedFilter: string = '';
  public products: PortfolioItem[] = [];
  allproducts!: PortfolioItem[]; // Use the PortfolioItem type

  public myOptions: NgxMasonryOptions = {
    horizontalOrder: true
  };

  ngOnInit() {
    this.products = Object.assign([], productList);
    this.allproducts = Object.assign([], productList);
  }

  filterItems(category: string) {
    this.selectedFilter = category
    if (category) {
      this.products = this.allproducts.filter((item: any) => {
        return item.category.includes(category)
      })
    } else {
      this.products = this.allproducts
    }
    console.log('products', this.products)
  }

}
