import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TopbarComponent } from './topbar/topbar.component';
import { FooterComponent } from './footer/footer.component';



@NgModule({
  declarations: [
    TopbarComponent,
    FooterComponent,

  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [TopbarComponent, FooterComponent, RouterModule]

})
export class SharedModule { }
