import { Component } from '@angular/core';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent {
  currentSection: any;

  ngOnInit():void{
    console.log(window.location.pathname)
    this.currentSection = (window.location.pathname).substring(1)
    console.log(this.currentSection)
  }
}
