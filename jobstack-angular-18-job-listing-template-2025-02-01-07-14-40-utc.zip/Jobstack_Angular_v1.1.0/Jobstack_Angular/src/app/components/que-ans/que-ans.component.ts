import { Component } from '@angular/core';

@Component({
  selector: 'app-que-ans',
  standalone: true,
  imports: [],
  templateUrl: './que-ans.component.html',
  styleUrl: './que-ans.component.scss'
})
export class QueAnsComponent {

}
