import { Component } from '@angular/core';

@Component({
  selector: 'app-job-sidebar',
  standalone: true,
  imports: [],
  templateUrl: './job-sidebar.component.html',
  styleUrl: './job-sidebar.component.scss'
})
export class JobSidebarComponent {

}
