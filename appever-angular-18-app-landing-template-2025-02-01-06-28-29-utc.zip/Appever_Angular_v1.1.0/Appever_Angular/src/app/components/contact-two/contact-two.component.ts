import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-two',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './contact-two.component.html',
  styleUrl: './contact-two.component.scss'
})
export class ContactTwoComponent {

}
