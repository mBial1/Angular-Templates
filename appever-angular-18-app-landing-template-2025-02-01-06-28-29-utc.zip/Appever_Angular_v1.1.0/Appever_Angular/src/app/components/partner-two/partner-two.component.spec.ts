import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerTwoComponent } from './partner-two.component';

describe('PartnerTwoComponent', () => {
  let component: PartnerTwoComponent;
  let fixture: ComponentFixture<PartnerTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PartnerTwoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PartnerTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
