import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about-one',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink
  ],
  templateUrl: './about-one.component.html',
  styleUrl: './about-one.component.scss'
})
export class AboutOneComponent {
  aboutData = [
    {
      icon:'shield',
      title: 'Enhance Security',
      desc:'There are many variations of passages of Lorem Ipsum available'
    },
    {
      icon:'aperture',
      title: 'High Performance',
      desc:'There are many variations of passages of Lorem Ipsum available'
    },
  ]
}
