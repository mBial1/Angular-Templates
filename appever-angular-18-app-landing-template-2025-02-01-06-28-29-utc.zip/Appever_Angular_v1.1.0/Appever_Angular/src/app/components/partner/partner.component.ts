import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-partner',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './partner.component.html',
  styleUrl: './partner.component.scss'
})
export class PartnerComponent {
  image:any = [
    "assets/images/client/amazon.svg",
    "assets/images/client/google.svg",
    "assets/images/client/lenovo.svg",
    "assets/images/client/paypal.svg",
    "assets/images/client/shopify.svg",
    "assets/images/client/spotify.svg",
  ]
}
