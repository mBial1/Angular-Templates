import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

import { tns } from 'tiny-slider';

interface Client {
    image: string;
    name: string;
    position: string;
    desc: string;
}
@Component({
  selector: 'app-client',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './client.component.html',
  styleUrl: './client.component.scss'
})
export class ClientComponent {
  client:Client[] = [
    {
      image:'assets/images/client/01.jpg',
      name:'Calvin Carlo',
      position:'Manager',
      desc:`" It seems that only fragments of the original text remain in the Lorem Ipsum texts used today. "`
    },
    {
      image:'assets/images/client/02.jpg',
      name:'Christa Smith',
      position:'Manager',
      desc:`" The most well-known dummy text is the 'Lorem Ipsum', which is said to have originated in the 16th century. "`
    },
    {
      image:'assets/images/client/03.jpg',
      name:'Jemina CLone',
      position:'Manager',
      desc:`" One disadvantage of Lorum Ipsum is that in Latin certain letters appear more frequently than others. "`
    },
    {
      image:'assets/images/client/04.jpg',
      name:'Smith Vodka',
      position:'Manager',
      desc:`" Thus, Lorem Ipsum has only limited suitability as a visual filler for German texts. "`
    },
    {
      image:'assets/images/client/05.jpg',
      name:'Cristino Murfi',
      position:'Manager',
      desc:`" There is now an abundance of readable dummy texts. These are usually used when a text is required. "`
    },
    {
      image:'assets/images/client/06.jpg',
      name:'Cristino Murfi',
      position:'Manager',
      desc:`" According to most sources, Lorum Ipsum can be traced back to a text composed by Cicero. "`
    },
  ]
  slider:any 

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    this.slider = tns({
      container: '.tiny-three-item',
      controls: false,
      mouseDrag: true,
      loop: true,
      rewind: true,
      autoplay: true,
      autoplayButtonOutput: false,
      autoplayTimeout: 3000,
      navPosition: "bottom",
      speed: 400,
      gutter: 12,
      responsive: {
          992: {
              items: 3
          },

          767: {
              items: 2
          },

          320: {
              items: 1
          },
      },
  }); 
  }

}
