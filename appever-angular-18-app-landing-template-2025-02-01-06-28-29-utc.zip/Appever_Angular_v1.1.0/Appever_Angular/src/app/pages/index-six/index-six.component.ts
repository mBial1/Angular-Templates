import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FeatureThreeComponent } from "../../components/feature-three/feature-three.component";
import { ScreenshotTwoComponent } from "../../components/screenshot-two/screenshot-two.component";
import { FaqTwoComponent } from "../../components/faq-two/faq-two.component";
import { ClientTwoComponent } from "../../components/client-two/client-two.component";
import { ContactTwoComponent } from "../../components/contact-two/contact-two.component";
import { PartnerTwoComponent } from "../../components/partner-two/partner-two.component";
import { FooterComponent } from "../../components/footer/footer.component";

@Component({
  selector: 'app-index-six',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NavbarComponent,
    FeatureThreeComponent,
    ScreenshotTwoComponent,
    FaqTwoComponent,
    ClientTwoComponent,
    ContactTwoComponent,
    PartnerTwoComponent,
    FooterComponent
],
  templateUrl: './index-six.component.html',
  styleUrl: './index-six.component.scss'
})
export class IndexSixComponent {


  currentSection: string | null = 'home';

  @HostListener('window:scroll', ['$event'])
  
  onWindowScroll() {
    const sections = document.querySelectorAll('section');
    
    let scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;

    sections.forEach((section) => {
      const sectionId = section.getAttribute('id');
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;

      if (scrollPos >= sectionTop - 50 && scrollPos < sectionTop + sectionHeight) {
        this.currentSection = sectionId;
      }
    });
  }
}
