import { Component, HostListener } from '@angular/core';
import { NavbarComponent } from "../../components/navbar/navbar.component";
import { CommonModule } from '@angular/common';
import { CountUpModule } from 'ngx-countup';

import { tns } from 'tiny-slider';
import { FeatureOneComponent } from "../../components/feature-one/feature-one.component";
import { AboutOneComponent } from "../../components/about-one/about-one.component";
import { AboutTwoComponent } from "../../components/about-two/about-two.component";
import { ScreenshotComponent } from "../../components/screenshot/screenshot.component";
import { FaqComponent } from "../../components/faq/faq.component";
import { DownloadComponent } from "../../components/download/download.component";
import { ClientComponent } from "../../components/client/client.component";
import { ContactComponent } from "../../components/contact/contact.component";
import { PartnerComponent } from "../../components/partner/partner.component";
import { FooterComponent } from "../../components/footer/footer.component";

@Component({
  selector: 'app-index-five',
  standalone: true,
  imports: [
    CommonModule,
    NavbarComponent,
    CountUpModule,
    FeatureOneComponent,
    AboutOneComponent,
    AboutTwoComponent,
    ScreenshotComponent,
    FaqComponent,
    DownloadComponent,
    ClientComponent,
    ContactComponent,
    PartnerComponent,
    FooterComponent
],
  templateUrl: './index-five.component.html',
  styleUrl: './index-five.component.scss'
})
export class IndexFiveComponent {
  currentSection: string | null = 'home';

  @HostListener('window:scroll', ['$event'])
  
  onWindowScroll() {
    const sections = document.querySelectorAll('section');
    
    let scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;

    sections.forEach((section) => {
      const sectionId = section.getAttribute('id');
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;

      if (scrollPos >= sectionTop - 50 && scrollPos < sectionTop + sectionHeight) {
        this.currentSection = sectionId;
      }
    });
  }

  images: string[] = [
    "assets/images/phone/1.png",
    "assets/images/phone/2.png",
    "assets/images/phone/3.png",
    "assets/images/phone/4.png",
    "assets/images/phone/5.png",
    "assets/images/phone/6.png",
  ]

  slider:any
  ngAfterViewInit(): void {
    this.slider = tns({
        container: '.tiny-single-item',
        items: 1,
        controls: false,
        mouseDrag: true,
        loop: true,
        rewind: true,
        autoplay: true,
        autoplayButtonOutput: false,
        autoplayTimeout: 3000,
        navPosition: "bottom",
        speed: 400,
        gutter: 0,
    }); 
  }

  open:boolean = false

  toggle(e:any){
    e.preventDefault()
    this.open = !this.open
  }
}
