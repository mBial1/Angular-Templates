import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FeatureOneComponent } from "../../components/feature-one/feature-one.component";
import { AboutOneComponent } from "../../components/about-one/about-one.component";
import { AboutTwoComponent } from "../../components/about-two/about-two.component";
import { ScreenshotComponent } from "../../components/screenshot/screenshot.component";
import { FaqComponent } from "../../components/faq/faq.component";
import { DownloadComponent } from "../../components/download/download.component";
import { ClientComponent } from "../../components/client/client.component";
import { ContactComponent } from "../../components/contact/contact.component";
import { PartnerComponent } from "../../components/partner/partner.component";
import { FooterComponent } from "../../components/footer/footer.component";

@Component({
  selector: 'app-index-one',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NavbarComponent,
    FeatureOneComponent,
    AboutOneComponent,
    AboutTwoComponent,
    ScreenshotComponent,
    FaqComponent,
    DownloadComponent,
    ClientComponent,
    ContactComponent,
    PartnerComponent,
    FooterComponent
],
  templateUrl: './index-one.component.html',
  styleUrl: './index-one.component.scss'
})
export class IndexOneComponent {
  currentSection: string | null = 'home';

  @HostListener('window:scroll', ['$event'])
  
  onWindowScroll() {
    const sections = document.querySelectorAll('section');
    let scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;

    sections.forEach((section) => {
      const sectionId = section.getAttribute('id');
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;

      if (scrollPos >= sectionTop - 50 && scrollPos < sectionTop + sectionHeight) {
        this.currentSection = sectionId;
      }
    });
  }
}
