import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IndexOneComponent } from './pages/index-one/index-one.component';
import { IndexTwoComponent } from './pages/index-two/index-two.component';
import { IndexThreeComponent } from './pages/index-three/index-three.component';
import { IndexFourComponent } from './pages/index-four/index-four.component';
import { IndexFiveComponent } from './pages/index-five/index-five.component';
import { IndexSixComponent } from './pages/index-six/index-six.component';

export const routes: Routes = [
    {path:'', component:IndexOneComponent},
    {path:'index-two', component:IndexTwoComponent},
    {path:'index-three', component:IndexThreeComponent},
    {path:'index-four', component:IndexFourComponent},
    {path:'index-five', component:IndexFiveComponent},
    {path:'index-six', component:IndexSixComponent},
];

@NgModule({
    imports: [
      RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' })
    ],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
