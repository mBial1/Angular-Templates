import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-section-video3',
  templateUrl: './section-video3.component.html',
  styleUrls: ['./section-video3.component.css']
})
export class SectionVideo3Component {

  @Input() back_image: any;

}
