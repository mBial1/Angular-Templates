import { Component } from '@angular/core';

@Component({
  selector: 'app-section-about-company4',
  templateUrl: './section-about-company4.component.html',
  styleUrls: ['./section-about-company4.component.css']
})
export class SectionAboutCompany4Component {

}
