import { Component } from '@angular/core';

@Component({
  selector: 'app-section-sidebar-gallery',
  templateUrl: './section-sidebar-gallery.component.html',
  styleUrls: ['./section-sidebar-gallery.component.css']
})
export class SectionSidebarGalleryComponent {

}
