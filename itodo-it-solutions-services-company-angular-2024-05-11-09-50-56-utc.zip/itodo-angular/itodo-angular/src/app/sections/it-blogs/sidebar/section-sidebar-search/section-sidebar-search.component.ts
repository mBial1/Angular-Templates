import { Component } from '@angular/core';

@Component({
  selector: 'app-section-sidebar-search',
  templateUrl: './section-sidebar-search.component.html',
  styleUrls: ['./section-sidebar-search.component.css']
})
export class SectionSidebarSearchComponent {

}
