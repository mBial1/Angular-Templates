import { Component } from '@angular/core';

@Component({
  selector: 'app-section-sidebar-categories',
  templateUrl: './section-sidebar-categories.component.html',
  styleUrls: ['./section-sidebar-categories.component.css']
})
export class SectionSidebarCategoriesComponent {

}
