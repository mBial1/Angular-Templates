import { Component } from '@angular/core';

@Component({
  selector: 'app-section-sidebar-posts',
  templateUrl: './section-sidebar-posts.component.html',
  styleUrls: ['./section-sidebar-posts.component.css']
})
export class SectionSidebarPostsComponent {

}
