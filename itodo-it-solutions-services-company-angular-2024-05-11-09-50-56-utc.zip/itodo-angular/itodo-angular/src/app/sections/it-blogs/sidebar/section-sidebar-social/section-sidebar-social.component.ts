import { Component } from '@angular/core';

@Component({
  selector: 'app-section-sidebar-social',
  templateUrl: './section-sidebar-social.component.html',
  styleUrls: ['./section-sidebar-social.component.css']
})
export class SectionSidebarSocialComponent {

}
