import { Component } from '@angular/core';

@Component({
  selector: 'app-section-leave-a-reply',
  templateUrl: './section-leave-a-reply.component.html',
  styleUrls: ['./section-leave-a-reply.component.css']
})
export class SectionLeaveAReplyComponent {

}
