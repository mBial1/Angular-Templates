import { Component } from '@angular/core';

@Component({
  selector: 'app-section-latest-news',
  templateUrl: './section-latest-news.component.html',
  styleUrls: ['./section-latest-news.component.css']
})
export class SectionLatestNewsComponent {

}
