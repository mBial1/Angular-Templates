import { Component } from '@angular/core';

@Component({
  selector: 'app-section-case-study3',
  templateUrl: './section-case-study3.component.html',
  styleUrls: ['./section-case-study3.component.css']
})
export class SectionCaseStudy3Component {

}
