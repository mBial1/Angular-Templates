import { Component } from '@angular/core';

@Component({
  selector: 'app-section-our-info1',
  templateUrl: './section-our-info1.component.html',
  styleUrls: ['./section-our-info1.component.css']
})
export class SectionOurInfo1Component {

}
