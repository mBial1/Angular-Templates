import { Component } from '@angular/core';

@Component({
  selector: 'app-section-case-study2',
  templateUrl: './section-case-study2.component.html',
  styleUrls: ['./section-case-study2.component.css']
})
export class SectionCaseStudy2Component {

}
