import { Component } from '@angular/core';

@Component({
  selector: 'app-section-about-company3',
  templateUrl: './section-about-company3.component.html',
  styleUrls: ['./section-about-company3.component.css']
})
export class SectionAboutCompany3Component {

}
