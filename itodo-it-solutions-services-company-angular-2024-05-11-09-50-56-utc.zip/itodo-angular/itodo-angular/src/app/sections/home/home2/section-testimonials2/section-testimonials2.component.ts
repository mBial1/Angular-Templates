import { Component } from '@angular/core';

@Component({
  selector: 'app-section-testimonials2',
  templateUrl: './section-testimonials2.component.html',
  styleUrls: ['./section-testimonials2.component.css']
})
export class SectionTestimonials2Component {

}
