import { Component } from '@angular/core';

@Component({
  selector: 'app-section-slider2',
  templateUrl: './section-slider2.component.html',
  styleUrls: ['./section-slider2.component.css']
})
export class SectionSlider2Component {

}
