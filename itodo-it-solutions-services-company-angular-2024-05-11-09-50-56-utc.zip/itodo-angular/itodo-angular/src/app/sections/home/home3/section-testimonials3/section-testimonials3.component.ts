import { Component } from '@angular/core';

@Component({
  selector: 'app-section-testimonials3',
  templateUrl: './section-testimonials3.component.html',
  styleUrls: ['./section-testimonials3.component.css']
})
export class SectionTestimonials3Component {

}
