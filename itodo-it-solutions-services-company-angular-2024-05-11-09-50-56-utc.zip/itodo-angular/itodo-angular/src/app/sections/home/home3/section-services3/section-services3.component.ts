import { Component } from '@angular/core';

@Component({
  selector: 'app-section-services3',
  templateUrl: './section-services3.component.html',
  styleUrls: ['./section-services3.component.css']
})
export class SectionServices3Component {

}
