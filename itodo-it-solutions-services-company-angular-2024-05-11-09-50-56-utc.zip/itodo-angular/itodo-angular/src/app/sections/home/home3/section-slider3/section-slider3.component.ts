import { Component } from '@angular/core';

@Component({
  selector: 'app-section-slider3',
  templateUrl: './section-slider3.component.html',
  styleUrls: ['./section-slider3.component.css']
})
export class SectionSlider3Component {

}
