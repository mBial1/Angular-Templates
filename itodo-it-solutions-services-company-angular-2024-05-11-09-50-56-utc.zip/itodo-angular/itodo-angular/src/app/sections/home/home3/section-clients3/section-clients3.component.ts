import { Component } from '@angular/core';

@Component({
  selector: 'app-section-clients3',
  templateUrl: './section-clients3.component.html',
  styleUrls: ['./section-clients3.component.css']
})
export class SectionClients3Component {

}
