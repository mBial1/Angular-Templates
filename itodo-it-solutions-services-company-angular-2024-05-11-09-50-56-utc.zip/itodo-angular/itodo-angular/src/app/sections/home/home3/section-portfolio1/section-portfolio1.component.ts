import { Component } from '@angular/core';

@Component({
  selector: 'app-section-portfolio1',
  templateUrl: './section-portfolio1.component.html',
  styleUrls: ['./section-portfolio1.component.css']
})
export class SectionPortfolio1Component {

}
