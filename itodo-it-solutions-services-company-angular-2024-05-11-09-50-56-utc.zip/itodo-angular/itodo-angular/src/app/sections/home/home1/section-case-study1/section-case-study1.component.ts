import { Component } from '@angular/core';

@Component({
  selector: 'app-section-case-study1',
  templateUrl: './section-case-study1.component.html',
  styleUrls: ['./section-case-study1.component.css']
})
export class SectionCaseStudy1Component {

}
