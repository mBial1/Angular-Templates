import { Component } from '@angular/core';

@Component({
  selector: 'app-section-slider1',
  templateUrl: './section-slider1.component.html',
  styleUrls: ['./section-slider1.component.css']
})
export class SectionSlider1Component {

}
