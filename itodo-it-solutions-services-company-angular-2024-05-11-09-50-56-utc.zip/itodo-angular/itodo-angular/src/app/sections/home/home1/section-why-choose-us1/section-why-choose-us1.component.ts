import { Component } from '@angular/core';

@Component({
  selector: 'app-section-why-choose-us1',
  templateUrl: './section-why-choose-us1.component.html',
  styleUrls: ['./section-why-choose-us1.component.css']
})
export class SectionWhyChooseUs1Component {

}
