import { Component } from '@angular/core';

@Component({
  selector: 'app-section-video1',
  templateUrl: './section-video1.component.html',
  styleUrls: ['./section-video1.component.css']
})
export class SectionVideo1Component {

}
