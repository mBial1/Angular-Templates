import { Component } from '@angular/core';

@Component({
  selector: 'app-section-clients1',
  templateUrl: './section-clients1.component.html',
  styleUrls: ['./section-clients1.component.css']
})
export class SectionClients1Component {

}
