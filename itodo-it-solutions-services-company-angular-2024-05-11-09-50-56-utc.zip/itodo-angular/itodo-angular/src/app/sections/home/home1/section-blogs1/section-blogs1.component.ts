import { Component } from '@angular/core';

@Component({
  selector: 'app-section-blogs1',
  templateUrl: './section-blogs1.component.html',
  styleUrls: ['./section-blogs1.component.css']
})
export class SectionBlogs1Component {

}
