import { Component } from '@angular/core';

@Component({
  selector: 'app-section-testimonials1',
  templateUrl: './section-testimonials1.component.html',
  styleUrls: ['./section-testimonials1.component.css']
})
export class SectionTestimonials1Component {

}
