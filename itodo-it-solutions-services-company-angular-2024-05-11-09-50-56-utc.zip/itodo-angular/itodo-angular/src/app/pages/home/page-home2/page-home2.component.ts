import { Component } from '@angular/core';

@Component({
  selector: 'app-page-home2',
  templateUrl: './page-home2.component.html',
  styleUrls: ['./page-home2.component.css']
})
export class PageHome2Component {

}
