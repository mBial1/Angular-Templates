import { Component } from '@angular/core';

@Component({
  selector: 'app-page-home1',
  templateUrl: './page-home1.component.html',
  styleUrls: ['./page-home1.component.css']
})
export class PageHome1Component {

}
