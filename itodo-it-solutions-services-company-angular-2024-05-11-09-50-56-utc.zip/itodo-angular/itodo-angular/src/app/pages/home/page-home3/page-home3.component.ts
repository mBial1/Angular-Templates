import { Component } from '@angular/core';

@Component({
  selector: 'app-page-home3',
  templateUrl: './page-home3.component.html',
  styleUrls: ['./page-home3.component.css']
})
export class PageHome3Component {

}
