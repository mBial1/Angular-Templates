import { Component } from '@angular/core';

@Component({
  selector: 'app-page-portfolio1',
  templateUrl: './page-portfolio1.component.html',
  styleUrls: ['./page-portfolio1.component.css']
})
export class PagePortfolio1Component {

}
