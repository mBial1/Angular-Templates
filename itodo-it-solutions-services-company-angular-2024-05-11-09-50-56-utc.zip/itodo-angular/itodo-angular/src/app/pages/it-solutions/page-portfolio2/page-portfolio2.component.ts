import { Component } from '@angular/core';

@Component({
  selector: 'app-page-portfolio2',
  templateUrl: './page-portfolio2.component.html',
  styleUrls: ['./page-portfolio2.component.css']
})
export class PagePortfolio2Component {

}
