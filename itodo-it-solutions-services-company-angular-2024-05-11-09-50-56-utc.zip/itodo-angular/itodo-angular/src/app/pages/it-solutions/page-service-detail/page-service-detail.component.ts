import { Component } from '@angular/core';

@Component({
  selector: 'app-page-service-detail',
  templateUrl: './page-service-detail.component.html',
  styleUrls: ['./page-service-detail.component.css']
})
export class PageServiceDetailComponent {

}
