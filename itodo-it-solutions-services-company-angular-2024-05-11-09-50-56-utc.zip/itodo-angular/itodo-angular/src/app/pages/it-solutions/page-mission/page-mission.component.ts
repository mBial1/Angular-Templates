import { Component } from '@angular/core';

@Component({
  selector: 'app-page-mission',
  templateUrl: './page-mission.component.html',
  styleUrls: ['./page-mission.component.css']
})
export class PageMissionComponent {

}
