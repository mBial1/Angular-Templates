import { Component } from '@angular/core';

@Component({
  selector: 'app-page-portfolio-detail',
  templateUrl: './page-portfolio-detail.component.html',
  styleUrls: ['./page-portfolio-detail.component.css']
})
export class PagePortfolioDetailComponent {

}
