import { Component } from '@angular/core';

@Component({
  selector: 'app-page-blog-detail-sidebar',
  templateUrl: './page-blog-detail-sidebar.component.html',
  styleUrls: ['./page-blog-detail-sidebar.component.css']
})
export class PageBlogDetailSidebarComponent {

}
