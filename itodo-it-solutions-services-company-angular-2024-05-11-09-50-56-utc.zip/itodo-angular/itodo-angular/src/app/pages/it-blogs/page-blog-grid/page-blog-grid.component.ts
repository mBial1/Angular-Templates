import { Component } from '@angular/core';

@Component({
  selector: 'app-page-blog-grid',
  templateUrl: './page-blog-grid.component.html',
  styleUrls: ['./page-blog-grid.component.css']
})
export class PageBlogGridComponent {

}
