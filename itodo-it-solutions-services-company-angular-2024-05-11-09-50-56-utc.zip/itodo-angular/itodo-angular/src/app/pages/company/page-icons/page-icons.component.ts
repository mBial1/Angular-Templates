import { Component } from '@angular/core';

@Component({
  selector: 'app-page-icons',
  templateUrl: './page-icons.component.html',
  styleUrls: ['./page-icons.component.css']
})
export class PageIconsComponent {

}
