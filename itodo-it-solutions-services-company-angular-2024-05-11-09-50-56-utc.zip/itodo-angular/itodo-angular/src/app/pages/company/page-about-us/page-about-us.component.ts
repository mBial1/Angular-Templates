import { Component } from '@angular/core';

@Component({
  selector: 'app-page-about-us',
  templateUrl: './page-about-us.component.html',
  styleUrls: ['./page-about-us.component.css']
})
export class PageAboutUsComponent {

}
