import { Component } from '@angular/core';

@Component({
  selector: 'app-page-team',
  templateUrl: './page-team.component.html',
  styleUrls: ['./page-team.component.css']
})
export class PageTeamComponent {

}
