import { Component } from '@angular/core';

@Component({
  selector: 'app-page-testimonials',
  templateUrl: './page-testimonials.component.html',
  styleUrls: ['./page-testimonials.component.css']
})
export class PageTestimonialsComponent {

}
