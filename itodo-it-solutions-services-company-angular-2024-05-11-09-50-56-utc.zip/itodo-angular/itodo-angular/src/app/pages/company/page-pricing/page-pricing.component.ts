import { Component } from '@angular/core';

@Component({
  selector: 'app-page-pricing',
  templateUrl: './page-pricing.component.html',
  styleUrls: ['./page-pricing.component.css']
})
export class PagePricingComponent {

}
