import { Component } from '@angular/core';

@Component({
  selector: 'app-page-gallery',
  templateUrl: './page-gallery.component.html',
  styleUrls: ['./page-gallery.component.css']
})
export class PageGalleryComponent {

}
