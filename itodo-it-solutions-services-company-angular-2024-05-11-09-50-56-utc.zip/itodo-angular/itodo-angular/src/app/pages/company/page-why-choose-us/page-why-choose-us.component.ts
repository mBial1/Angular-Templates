import { Component } from '@angular/core';

@Component({
  selector: 'app-page-why-choose-us',
  templateUrl: './page-why-choose-us.component.html',
  styleUrls: ['./page-why-choose-us.component.css']
})
export class PageWhyChooseUsComponent {

}
