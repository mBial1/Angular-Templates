import { Component } from '@angular/core';

@Component({
  selector: 'app-page-faq',
  templateUrl: './page-faq.component.html',
  styleUrls: ['./page-faq.component.css']
})
export class PageFaqComponent {

}
