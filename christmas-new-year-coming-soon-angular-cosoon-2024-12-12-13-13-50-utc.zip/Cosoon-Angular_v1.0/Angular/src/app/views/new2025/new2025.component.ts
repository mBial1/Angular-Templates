import { DOCUMENT } from '@angular/common'
import {
  Component,
  HostListener,
  Inject,
  OnDestroy,
  OnInit,
  Renderer2,
} from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'
interface Fire {
  x: number
  y: number
  size: number
  fill: string
  vx: number
  vy: number
  ax: number
  far: number
  base: { x: number; y: number; vx: number }
}

interface Firework {
  x: number
  y: number
  size: number
  fill: string
  vx: number
  vy: number
  ay: number
  alpha: number
  life: number
  base: { life: number; size: number }
}

@Component({
  selector: 'app-new2025',
  standalone: true,
  imports: [],
  templateUrl: './new2025.component.html',
  styles: ``,
})
export class New2025Component implements OnInit, OnDestroy {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }

  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}
  private subscription: Subscription | null = null

  private canvas!: HTMLCanvasElement
  private ctx!: CanvasRenderingContext2D
  private listFire: Fire[] = []
  private listFirework: Firework[] = []
  private fireNumber = 10
  private center = { x: 0, y: 0 }
  private range = 100

  ngOnInit() {
    this.canvas = document.getElementById('canvas') as HTMLCanvasElement
    this.ctx = this.canvas.getContext('2d') as CanvasRenderingContext2D
    this.resizeCanvas()
    this.initializeFires()
    this.loop()

    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'overflow-hidden')
    this.renderer.addClass(this.document.body, 'bg-dark')
    this.renderer.addClass(this.document.body, 'text-center')

    const targetDate = '2025-01-01T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'overflow-hidden')
    this.renderer.removeClass(this.document.body, 'bg-dark')
    this.renderer.removeClass(this.document.body, 'text-center')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.resizeCanvas()
  }

  private resizeCanvas() {
    this.canvas.width = window.innerWidth
    this.canvas.height = window.innerHeight
    this.ctx.fillStyle = '#000'
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)
    this.center = { x: this.canvas.width / 2, y: this.canvas.height / 2 }
  }

  private initializeFires() {
    for (let i = 0; i < this.fireNumber; i++) {
      const fire: Fire = {
        x: Math.random() * this.range - this.range / 2 + this.center.x,
        y: Math.random() * this.range + this.canvas.height,
        size: Math.random() + 0.5,
        fill: '#fd1',
        vx: Math.random() - 0.5,
        vy: -(Math.random() + 4),
        ax: Math.random() * 0.02 - 0.01,
        far: Math.random() * this.range + (this.center.y - this.range),
        base: { x: 0, y: 0, vx: 0 },
      }
      fire.base = { x: fire.x, y: fire.y, vx: fire.vx }
      this.listFire.push(fire)
    }
  }

  private randColor() {
    const r = Math.floor(Math.random() * 256)
    const g = Math.floor(Math.random() * 256)
    const b = Math.floor(Math.random() * 256)
    return `rgb(${r}, ${g}, ${b})`
  }

  private update() {
    this.listFire.forEach((fire) => {
      if (fire.y <= fire.far) {
        const color = this.randColor()
        for (let i = 0; i < this.fireNumber * 5; i++) {
          const firework: Firework = {
            x: fire.x,
            y: fire.y,
            size: Math.random() + 1.5,
            fill: color,
            vx: Math.random() * 5 - 2.5,
            vy: Math.random() * -5 + 1.5,
            ay: 0.05,
            alpha: 1,
            life: Math.round((Math.random() * this.range) / 2) + this.range / 2,
            base: { life: 0, size: 0 },
          }
          firework.base = { life: firework.life, size: firework.size }
          this.listFirework.push(firework)
        }
        fire.y = fire.base.y
        fire.x = fire.base.x
        fire.vx = fire.base.vx
        fire.ax = Math.random() * 0.02 - 0.01
      }
      fire.x += fire.vx
      fire.y += fire.vy
      fire.vx += fire.ax
    })

    for (let i = this.listFirework.length - 1; i >= 0; i--) {
      const firework = this.listFirework[i]
      firework.x += firework.vx
      firework.y += firework.vy
      firework.vy += firework.ay
      firework.alpha = firework.life / firework.base.life
      firework.size = firework.alpha * firework.base.size
      firework.alpha = firework.alpha > 0.6 ? 1 : firework.alpha
      firework.life--
      if (firework.life <= 0) {
        this.listFirework.splice(i, 1)
      }
    }
  }

  private draw() {
    this.ctx.globalCompositeOperation = 'source-over'
    this.ctx.globalAlpha = 0.18
    this.ctx.fillStyle = '#000'
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)

    this.ctx.globalCompositeOperation = 'screen'
    this.ctx.globalAlpha = 1
    this.listFire.forEach((fire) => {
      this.ctx.beginPath()
      this.ctx.arc(fire.x, fire.y, fire.size, 0, Math.PI * 2)
      this.ctx.closePath()
      this.ctx.fillStyle = fire.fill
      this.ctx.fill()
    })

    this.listFirework.forEach((firework) => {
      this.ctx.globalAlpha = firework.alpha
      this.ctx.beginPath()
      this.ctx.arc(firework.x, firework.y, firework.size, 0, Math.PI * 2)
      this.ctx.closePath()
      this.ctx.fillStyle = firework.fill
      this.ctx.fill()
    })
  }

  private loop() {
    requestAnimationFrame(() => this.loop())
    this.update()
    this.draw()
  }
}

//   ngOnInit(): void {
//     this.renderer.addClass(this.document.body, 'h-100');
//     this.renderer.addClass(this.document.body, 'overflow-hidden');
//     this.renderer.addClass(this.document.body, 'bg-dark');
// this.renderer.addClass(this.document.body, 'text-center');
//   }

//   ngOnDestroy(): void {
//     this.renderer.removeClass(this.document.body, 'h-100');
//     this.renderer.removeClass(this.document.body, 'overflow-hidden');
//     this.renderer.removeClass(this.document.body, 'bg-dark');
// this.renderer.removeClass(this.document.body, 'text-center');
//   }
