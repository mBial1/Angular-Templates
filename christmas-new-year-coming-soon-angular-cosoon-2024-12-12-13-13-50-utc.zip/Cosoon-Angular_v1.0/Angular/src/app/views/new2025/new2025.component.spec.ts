import { ComponentFixture, TestBed } from '@angular/core/testing'

import { New2025Component } from './new2025.component'

describe('New2025Component', () => {
  let component: New2025Component
  let fixture: ComponentFixture<New2025Component>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [New2025Component],
    }).compileComponents()

    fixture = TestBed.createComponent(New2025Component)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
