import { DOCUMENT } from '@angular/common'
import { Component, Inject, Renderer2 } from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'
import { FontService } from '../../service/font.service'

@Component({
  selector: 'app-gold',
  standalone: true,
  imports: [],
  templateUrl: './gold.component.html',
  styles: ``,
})
export class GoldComponent {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }

  constructor(
    private fontService: FontService,
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}
  private subscription: Subscription | null = null

  ngOnInit() {
    this.fontService.loadFont(
      'https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap'
    )

    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'bg-christmas-gold')

    const targetDate = '2024-12-25T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'bg-christmas-gold')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }
}
