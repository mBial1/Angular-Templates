import { DOCUMENT } from '@angular/common'
import { Component, Inject, Renderer2 } from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-new-year',
  standalone: true,
  imports: [],
  templateUrl: './new-year.component.html',
  styles: ``,
})
export class NewYearComponent {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }

  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}
  private subscription: Subscription | null = null

  ngOnInit() {
    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'bg-newyear-postcard')
    this.renderer.addClass(this.document.body, 'text-center')

    const targetDate = '2025-01-01T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'bg-newyear-postcard')
    this.renderer.removeClass(this.document.body, 'text-center')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }
}
