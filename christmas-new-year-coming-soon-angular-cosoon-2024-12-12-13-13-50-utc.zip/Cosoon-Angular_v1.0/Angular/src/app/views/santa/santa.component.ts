import { DOCUMENT } from '@angular/common'
import { Component, Inject, OnDestroy, OnInit, Renderer2 } from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'
import { FontService } from '../../service/font.service'

@Component({
  selector: 'app-santa',
  standalone: true,
  imports: [],
  templateUrl: './santa.component.html',
  providers: [FontService],

  styles: ``,
})
export class SantaComponent implements OnInit, OnDestroy {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }

  constructor(
    private fontService: FontService,
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}
  private subscription: Subscription | null = null

  ngOnInit(): void {
    this.fontService.loadFont(
      'https://fonts.googleapis.com/css2?family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap'
    )
    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'bg-christmas-santa')
    this.renderer.addClass(this.document.body, 'text-center')
    this.renderer.addClass(this.document.body, 'text-white')

    const targetDate = '2024-12-25T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'bg-christmas-santa')
    this.renderer.removeClass(this.document.body, 'text-center')
    this.renderer.removeClass(this.document.body, 'text-white')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }
}
