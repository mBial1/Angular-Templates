import { DOCUMENT } from '@angular/common'
import { Component, Inject, OnDestroy, OnInit, Renderer2 } from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-index',
  standalone: true,
  imports: [],
  templateUrl: './index.component.html',
  styles: ``,
})
export class IndexComponent implements OnInit, OnDestroy {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }
  private subscription: Subscription | null = null
  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}

  ngOnInit(): void {
    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'bg-christmas-red')
    this.renderer.addClass(this.document.body, 'text-white')

    const targetDate = '2024-12-25T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'bg-christmas-red')
    this.renderer.removeClass(this.document.body, 'text-white')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }
}
