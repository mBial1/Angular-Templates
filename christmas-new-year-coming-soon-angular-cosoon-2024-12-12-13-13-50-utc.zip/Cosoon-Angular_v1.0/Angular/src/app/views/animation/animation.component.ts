import { DOCUMENT } from '@angular/common'
import { Component, Inject, OnDestroy, OnInit, Renderer2 } from '@angular/core'
import { CountdownService } from '../../service/countdown.service'
import { Subscription } from 'rxjs'
import { CssLoaderService } from '../../service/css-loader.service'

@Component({
  selector: 'app-animation',
  standalone: true,
  imports: [],
  templateUrl: './animation.component.html',
  styles: ``,
})
export class AnimationComponent implements OnInit, OnDestroy {
  countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 }

  constructor(
    private renderer: Renderer2,
    private cssLoaderService: CssLoaderService,
    @Inject(DOCUMENT) private document: Document,
    private countdownService: CountdownService
  ) {}
  private subscription: Subscription | null = null

  ngOnInit() {
    this.cssLoaderService.loadCss('css/animation.css', 'app-style')

    this.renderer.addClass(this.document.body, 'h-100')
    this.renderer.addClass(this.document.body, 'bg-dark')
    this.renderer.addClass(this.document.body, 'text-center')
    this.renderer.addClass(this.document.body, 'overflow-hidden')

    const targetDate = '2024-12-25T12:00:01' // Set your target date
    this.countdownService.startCountdown(targetDate)

    this.subscription = this.countdownService.countdown$.subscribe(
      (time) => (this.countdown = time)
    )
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'h-100')
    this.renderer.removeClass(this.document.body, 'bg-dark')
    this.renderer.removeClass(this.document.body, 'text-center')
    this.renderer.removeClass(this.document.body, 'overflow-hidden')

    if (this.subscription) {
      this.subscription.unsubscribe()
    }
    this.countdownService.stopCountdown()
  }
}
