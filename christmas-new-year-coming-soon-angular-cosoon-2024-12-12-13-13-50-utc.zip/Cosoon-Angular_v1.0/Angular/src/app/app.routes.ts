import { Routes } from '@angular/router'
import { IndexComponent } from './views/index/index.component'
import { AnimationComponent } from './views/animation/animation.component'
import { BoomComponent } from './views/boom/boom.component'
import { GoldComponent } from './views/gold/gold.component'
import { LeafComponent } from './views/leaf/leaf.component'
import { NewYearComponent } from './views/new-year/new-year.component'
import { New2025Component } from './views/new2025/new2025.component'
import { PineComponent } from './views/pine/pine.component'
import { SnowComponent } from './views/snow/snow.component'
import { SantaComponent } from './views/santa/santa.component'

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'index',
    pathMatch: 'full',
  },
  {
    path: 'index',
    component: IndexComponent,
  },
  {
    path: 'animation',
    component: AnimationComponent,
  },
  {
    path: 'boom',
    component: BoomComponent,
  },
  {
    path: 'gold',
    component: GoldComponent,
  },
  {
    path: 'leaf',
    component: LeafComponent,
  },
  {
    path: 'new-year',
    component: NewYearComponent,
  },
  {
    path: '2025',
    component: New2025Component,
  },
  {
    path: 'pine',
    component: PineComponent,
  },
  {
    path: 'santa',
    component: SantaComponent,
  },
  {
    path: 'snow',
    component: SnowComponent,
  },
]
