import { Injectable } from '@angular/core'

@Injectable({
  providedIn: 'root',
})
export class CssLoaderService {
  private currentCssLink: HTMLLinkElement | null = null

  constructor() {}

  loadCss(url: string, id: string) {
    if (this.currentCssLink) {
      document.head.removeChild(this.currentCssLink)
    }

    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.type = 'text/css'
    link.href = url
    link.id = id
    document.head.appendChild(link)
    this.currentCssLink = link
  }
}
