// src/app/services/font.service.ts
import { Injectable } from '@angular/core'

@Injectable({
  providedIn: 'root',
})
export class FontService {
  private currentFontLink: HTMLLinkElement | null = null

  constructor() {}

  loadFont(url: string) {
    if (this.currentFontLink) {
      document.head.removeChild(this.currentFontLink)
    }

    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = url
    document.head.appendChild(link)
    this.currentFontLink = link
  }
}
