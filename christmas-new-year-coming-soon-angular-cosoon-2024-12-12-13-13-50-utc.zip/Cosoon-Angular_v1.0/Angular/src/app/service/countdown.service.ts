import { Injectable } from '@angular/core'
import { BehaviorSubject, interval, Subscription } from 'rxjs'
import { map } from 'rxjs/operators'

@Injectable({
  providedIn: 'root',
})
export class CountdownService {
  private intervalSubscription: Subscription | null = null

  private countdownSource = new BehaviorSubject<{
    days: number
    hours: number
    minutes: number
    seconds: number
  }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  countdown$ = this.countdownSource.asObservable()

  startCountdown(targetDate: string): void {
    if (this.intervalSubscription) {
      this.intervalSubscription.unsubscribe()
    }

    const endDate = new Date(targetDate).getTime()

    this.intervalSubscription = interval(1000)
      .pipe(
        map(() => {
          const now = new Date().getTime()
          const timeDiff = endDate - now

          if (timeDiff <= 0) {
            this.stopCountdown()
            return { days: 0, hours: 0, minutes: 0, seconds: 0 }
          }

          const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24))
          const hours = Math.floor(
            (timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
          )
          const minutes = Math.floor(
            (timeDiff % (1000 * 60 * 60)) / (1000 * 60)
          )
          const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000)

          return { days, hours, minutes, seconds }
        })
      )
      .subscribe((time) => this.countdownSource.next(time))
  }

  stopCountdown(): void {
    if (this.intervalSubscription) {
      this.intervalSubscription.unsubscribe()
      this.intervalSubscription = null
    }
  }
}
