import {
  isPlatformBrowser
} from "./chunk-PH4NEIZN.js";
import {
  Directive,
  ElementRef,
  Inject,
  Injectable,
  Input,
  NgModule,
  PLATFORM_ID,
  Renderer2,
  Subject,
  debounceTime,
  filter,
  fromEvent,
  map,
  mergeMap,
  of,
  setClassMetadata,
  takeUntil,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵinject
} from "./chunk-RDSL6AL2.js";
import "./chunk-J4B6MK7R.js";

// node_modules/@yoozly/ngx-parallax/fesm2022/yoozly-ngx-parallax.mjs
var BrowserWindowRef = class _BrowserWindowRef {
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
  }
  get nativeWindow() {
    if (isPlatformBrowser(this.platformId)) {
      return this.windowRef();
    }
    return false;
  }
  windowRef() {
    return window;
  }
  static ɵfac = function BrowserWindowRef_Factory(t) {
    return new (t || _BrowserWindowRef)(ɵɵinject(PLATFORM_ID));
  };
  static ɵprov = ɵɵdefineInjectable({
    token: _BrowserWindowRef,
    factory: _BrowserWindowRef.ɵfac,
    providedIn: "root"
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrowserWindowRef, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: void 0,
    decorators: [{
      type: Inject,
      args: [PLATFORM_ID]
    }]
  }], null);
})();
var ParallaxDirective = class _ParallaxDirective {
  hostElement;
  renderer;
  wr;
  speed = 30;
  axe = "y";
  property = "transform";
  propertyValue = "translate3d";
  active = true;
  inViewport = true;
  observer;
  element;
  initialPosition;
  componentDestroy$ = new Subject();
  windowScroll$;
  windowResize$;
  constructor(hostElement, renderer, wr) {
    this.hostElement = hostElement;
    this.renderer = renderer;
    this.wr = wr;
  }
  ngAfterViewInit() {
    this.element = this.hostElement.nativeElement;
    if (this.element && this.wr.nativeWindow && !this.observer) {
      this.initParallax();
    }
  }
  initParallax() {
    this.observer = this.createObserver(0);
    this.observer.observe(this.element);
    const parallax$ = of("").pipe(takeUntil(this.componentDestroy$), filter(() => this.active && this.inViewport), map(() => {
      const coef = this.calculateCoef();
      this.renderParallax(coef);
      return coef;
    }));
    this.windowScroll$ = fromEvent(this.wr.nativeWindow, "scroll").pipe(mergeMap(() => parallax$));
    this.windowResize$ = fromEvent(this.wr.nativeWindow, "resize").pipe(debounceTime(500), mergeMap(() => parallax$));
  }
  startParallax() {
    this.inViewport = true;
    if (this.wr.nativeWindow && this.initialPosition === void 0) {
      this.initialPosition = this.wr.nativeWindow.pageYOffset;
      this.windowScroll$.subscribe();
      this.windowResize$.subscribe();
    }
  }
  destroyParallax() {
    this.inViewport = false;
  }
  calculateCoef() {
    return (this.wr.nativeWindow.pageYOffset - this.initialPosition) * (this.speed / 100);
  }
  renderParallax(coef) {
    this.renderer.setStyle(this.element, this.property, this.getPropertyValue(coef));
  }
  getPropertyValue(coef) {
    let result = `${coef}px`;
    if (this.property === "transform") {
      switch (this.propertyValue) {
        case "translate3d":
          result = `translate3d(${this.getAxe(coef)})`;
          break;
        case "scale":
          result = `scale(${coef})`;
          break;
        case "rotate":
          result = `rotate(${coef}deg)`;
          break;
      }
    }
    switch (this.property) {
      case "opacity":
        result = `${coef}`;
        break;
    }
    return result;
  }
  getAxe(coef) {
    let axe = [0, coef, 0];
    if (this.axe === "x") {
      axe = [coef, 0, 0];
    } else if (this.axe === "z") {
      axe = [0, 0, coef];
    }
    return `${axe[0]}px, ${axe[1]}px, ${axe[2]}px`;
  }
  createObserver(pourcent) {
    const options = {
      rootMargin: "0px",
      threshold: pourcent / 100
    };
    const isIntersecting = (entry) => entry.isIntersecting || entry.intersectionRatio > 0;
    return new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (isIntersecting(entry)) {
          this.startParallax();
        } else {
          this.destroyParallax();
        }
      });
    }, options);
  }
  ngOnDestroy() {
    this.componentDestroy$.next(false);
    this.componentDestroy$.complete();
    if (this.wr.nativeWindow) {
      this.observer.disconnect();
    }
  }
  static ɵfac = function ParallaxDirective_Factory(t) {
    return new (t || _ParallaxDirective)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(BrowserWindowRef));
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ParallaxDirective,
    selectors: [["", "ngx-parallax", ""]],
    inputs: {
      speed: "speed",
      axe: "axe",
      property: "property",
      propertyValue: "propertyValue",
      active: "active"
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ParallaxDirective, [{
    type: Directive,
    args: [{
      selector: "[ngx-parallax]"
    }]
  }], () => [{
    type: ElementRef
  }, {
    type: Renderer2
  }, {
    type: BrowserWindowRef
  }], {
    speed: [{
      type: Input
    }],
    axe: [{
      type: Input
    }],
    property: [{
      type: Input
    }],
    propertyValue: [{
      type: Input
    }],
    active: [{
      type: Input
    }]
  });
})();
var NgxParallaxModule = class _NgxParallaxModule {
  static ɵfac = function NgxParallaxModule_Factory(t) {
    return new (t || _NgxParallaxModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _NgxParallaxModule,
    declarations: [ParallaxDirective],
    exports: [ParallaxDirective]
  });
  static ɵinj = ɵɵdefineInjector({});
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxParallaxModule, [{
    type: NgModule,
    args: [{
      declarations: [ParallaxDirective],
      imports: [],
      exports: [ParallaxDirective]
    }]
  }], null, null);
})();
var ParallaxStandaloneDirective = class _ParallaxStandaloneDirective {
  hostElement;
  renderer;
  wr;
  speed = 30;
  axe = "y";
  property = "transform";
  propertyValue = "translate3d";
  active = true;
  inViewport = true;
  observer;
  element;
  initialPosition;
  componentDestroy$ = new Subject();
  windowScroll$;
  windowResize$;
  constructor(hostElement, renderer, wr) {
    this.hostElement = hostElement;
    this.renderer = renderer;
    this.wr = wr;
  }
  ngAfterViewInit() {
    this.element = this.hostElement.nativeElement;
    if (this.element && this.wr.nativeWindow && !this.observer) {
      this.initParallax();
    }
  }
  initParallax() {
    this.observer = this.createObserver(0);
    this.observer.observe(this.element);
    const parallax$ = of("").pipe(takeUntil(this.componentDestroy$), filter(() => this.active && this.inViewport), map(() => {
      const coef = this.calculateCoef();
      this.renderParallax(coef);
      return coef;
    }));
    this.windowScroll$ = fromEvent(this.wr.nativeWindow, "scroll").pipe(mergeMap(() => parallax$));
    this.windowResize$ = fromEvent(this.wr.nativeWindow, "resize").pipe(debounceTime(500), mergeMap(() => parallax$));
  }
  startParallax() {
    this.inViewport = true;
    if (this.wr.nativeWindow && this.initialPosition === void 0) {
      this.initialPosition = this.wr.nativeWindow.pageYOffset;
      this.windowScroll$.subscribe();
      this.windowResize$.subscribe();
    }
  }
  destroyParallax() {
    this.inViewport = false;
  }
  calculateCoef() {
    return (this.wr.nativeWindow.pageYOffset - this.initialPosition) * (this.speed / 100);
  }
  renderParallax(coef) {
    this.renderer.setStyle(this.element, this.property, this.getPropertyValue(coef));
  }
  getPropertyValue(coef) {
    let result = `${coef}px`;
    if (this.property === "transform") {
      switch (this.propertyValue) {
        case "translate3d":
          result = `translate3d(${this.getAxe(coef)})`;
          break;
        case "scale":
          result = `scale(${coef})`;
          break;
        case "rotate":
          result = `rotate(${coef}deg)`;
          break;
      }
    }
    switch (this.property) {
      case "opacity":
        result = `${coef}`;
        break;
    }
    return result;
  }
  getAxe(coef) {
    let axe = [0, coef, 0];
    if (this.axe === "x") {
      axe = [coef, 0, 0];
    } else if (this.axe === "z") {
      axe = [0, 0, coef];
    }
    return `${axe[0]}px, ${axe[1]}px, ${axe[2]}px`;
  }
  createObserver(pourcent) {
    const options = {
      rootMargin: "0px",
      threshold: pourcent / 100
    };
    const isIntersecting = (entry) => entry.isIntersecting || entry.intersectionRatio > 0;
    return new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (isIntersecting(entry)) {
          this.startParallax();
        } else {
          this.destroyParallax();
        }
      });
    }, options);
  }
  ngOnDestroy() {
    this.componentDestroy$.next(false);
    this.componentDestroy$.complete();
    if (this.wr.nativeWindow) {
      this.observer.disconnect();
    }
  }
  static ɵfac = function ParallaxStandaloneDirective_Factory(t) {
    return new (t || _ParallaxStandaloneDirective)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(BrowserWindowRef));
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ParallaxStandaloneDirective,
    selectors: [["", "ngx-parallax", ""]],
    inputs: {
      speed: "speed",
      axe: "axe",
      property: "property",
      propertyValue: "propertyValue",
      active: "active"
    },
    standalone: true
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ParallaxStandaloneDirective, [{
    type: Directive,
    args: [{
      selector: "[ngx-parallax]",
      standalone: true
    }]
  }], () => [{
    type: ElementRef
  }, {
    type: Renderer2
  }, {
    type: BrowserWindowRef
  }], {
    speed: [{
      type: Input
    }],
    axe: [{
      type: Input
    }],
    property: [{
      type: Input
    }],
    propertyValue: [{
      type: Input
    }],
    active: [{
      type: Input
    }]
  });
})();
export {
  NgxParallaxModule,
  ParallaxDirective,
  ParallaxStandaloneDirective
};
//# sourceMappingURL=@yoozly_ngx-parallax.js.map
