import {Routes} from '@angular/router';

// Screens
import {FaqComponent} from './screens/faq/faq.component';
import {MoreComponent} from './screens/more/more.component';
import {LoansComponent} from './screens/loans/loans.component';
import {SignInComponent} from './screens/sign-in/sign-in.component';
import {SignUpComponent} from './screens/sign-up/sign-up.component';
import {ProfileComponent} from './screens/profile/profile.component';
import {PaymentsComponent} from './screens/payments/payments.component';
import {CardMenuComponent} from './screens/card-menu/card-menu.component';
import {StatisticsComponent} from './screens/statistics/statistics.component';
import {OnboardingComponent} from './screens/onboarding/onboarding.component';
import {OpenDepositComponent} from './screens/open-deposit/open-deposit.component';
import {InvoiceSentComponent} from './screens/invoice-sent/invoice-sent.component';
import {CardDetailsComponent} from './screens/card-details/card-details.component';
import {NewPasswordComponent} from './screens/new-password/new-password.component';
import {IbanPaymentComponent} from './screens/iban-payment/iban-payment.component';
import {NotificationComponent} from './screens/notification/notification.component';
import {OpenNewCardComponent} from './screens/open-new-card/open-new-card.component';
import {OpenNewLoanComponent} from './screens/open-new-loan/open-new-loan.component';
import {TabNavigatorComponent} from './screens/tab-navigator/tab-navigator.component';
import {OpenMoneyboxComponent} from './screens/open-moneybox/open-moneybox.component';
import {FundTransferComponent} from './screens/fund-transfer/fund-transfer.component';
import {TopUpPaymentComponent} from './screens/top-up-payment/top-up-payment.component';
import {CreateInvoiceComponent} from './screens/create-invoice/create-invoice.component';
import {MobilePaymentComponent} from './screens/mobile-payment/mobile-payment.component';
import {PrivacyPolicyComponent} from './screens/privacy-policy/privacy-policy.component';
import {PaymentFailedComponent} from './screens/payment-failed/payment-failed.component';
import {ChangePinCodeComponent} from './screens/change-pin-code/change-pin-code.component';
import {PaymentSuccessComponent} from './screens/payment-success/payment-success.component';
import {ForgotPasswordComponent} from './screens/forgot-password/forgot-password.component';
import {ConfirmationCodeComponent} from './screens/confirmation-code/confirmation-code.component';
import {EditPersonalInfoComponent} from './screens/edit-personal-info/edit-personal-info.component';
import {TransactionDetailsComponent} from './screens/transaction-details/transaction-details.component';
import {SignUpAccountCreatedComponent} from './screens/sign-up-account-created/sign-up-account-created.component';
import {VerifyYourPhoneNumberComponent} from './screens/verify-your-phone-number/verify-your-phone-number.component';
import {ForgotPasswordSentEmailComponent} from './screens/forgot-password-sent-email/forgot-password-sent-email.component';

export const routes: Routes = [
  {
    path: '',
    component: OnboardingComponent,
  },
  {
    path: 'sign-in',
    component: SignInComponent,
  },
  {
    path: 'sign-up',
    component: SignUpComponent,
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
  },
  {
    path: 'new-password',
    component: NewPasswordComponent,
  },
  {
    path: 'forgot-password-sent-email',
    component: ForgotPasswordSentEmailComponent,
  },
  {
    path: 'sign-up-account-created',
    component: SignUpAccountCreatedComponent,
  },
  {
    path: 'verify-your-phone-number',
    component: VerifyYourPhoneNumberComponent,
  },
  {
    path: 'confirmation-code',
    component: ConfirmationCodeComponent,
  },
  {
    path: 'tab-navigator',
    component: TabNavigatorComponent,
  },
  {
    path: 'payment-success',
    component: PaymentSuccessComponent,
  },
  {
    path: 'profile',
    component: ProfileComponent,
  },
  {
    path: 'payment-failed',
    component: PaymentFailedComponent,
  },
  {
    path: 'transaction-details',
    component: TransactionDetailsComponent,
  },
  {
    path: 'iban-payment',
    component: IbanPaymentComponent,
  },
  {
    path: 'fund-transfer',
    component: FundTransferComponent,
  },
  {
    path: 'mobile-payment',
    component: MobilePaymentComponent,
  },
  {
    path: 'top-up-payment',
    component: TopUpPaymentComponent,
  },
  {
    path: 'payments',
    component: PaymentsComponent,
  },
  {
    path: 'change-pin-code',
    component: ChangePinCodeComponent,
  },
  {
    path: 'card-details',
    component: CardDetailsComponent,
  },
  {
    path: 'card-menu',
    component: CardMenuComponent,
  },
  {
    path: 'edit-personal-info',
    component: EditPersonalInfoComponent,
  },
  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent,
  },
  {
    path: 'faq',
    component: FaqComponent,
  },
  {
    path: 'statistics',
    component: StatisticsComponent,
  },
  {
    path: 'invoice-sent',
    component: InvoiceSentComponent,
  },
  {
    path: 'create-invoice',
    component: CreateInvoiceComponent,
  },
  {
    path: 'open-new-card',
    component: OpenNewCardComponent,
  },
  {
    path: 'more',
    component: MoreComponent,
  },
  {
    path: 'notification',
    component: NotificationComponent,
  },
  {
    path: 'open-new-loan',
    component: OpenNewLoanComponent,
  },
  {
    path: 'loans',
    component: LoansComponent,
  },
  {
    path: 'open-moneybox',
    component: OpenMoneyboxComponent,
  },
  {
    path: 'open-deposit',
    component: OpenDepositComponent,
  },
];
