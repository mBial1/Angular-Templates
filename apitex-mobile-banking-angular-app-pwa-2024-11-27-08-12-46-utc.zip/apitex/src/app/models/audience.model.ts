export interface Audience {
  id: number;
  name: string;
}
