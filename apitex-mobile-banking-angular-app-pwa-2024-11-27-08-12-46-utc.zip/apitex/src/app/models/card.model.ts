export type CardType = {
  id: number;
  type: string;
  balance: string;
  number: string;
  image: string;
};
