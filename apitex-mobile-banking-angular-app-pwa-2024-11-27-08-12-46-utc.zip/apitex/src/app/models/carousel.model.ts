export interface Carousel {
  id: number;
  image: string;
  promotion: string;
}
