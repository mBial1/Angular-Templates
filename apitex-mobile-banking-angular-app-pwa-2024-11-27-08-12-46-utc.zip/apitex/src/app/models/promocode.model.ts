export interface Promocode {
  id: number;
  code: string;
  image: string;
  discount: number;
  expiry: string;
}
