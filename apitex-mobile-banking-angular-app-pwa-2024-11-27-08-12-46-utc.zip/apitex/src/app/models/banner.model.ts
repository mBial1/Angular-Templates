export interface Banner {
  id: number;
  image: string;
  promotion: string;
}
