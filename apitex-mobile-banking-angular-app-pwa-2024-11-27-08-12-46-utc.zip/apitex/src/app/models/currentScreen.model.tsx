export interface TabState {
  currentScreen: string;
}
