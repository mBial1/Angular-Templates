// store/selectors/products.selectors.ts
import {createSelector} from '@ngrx/store';
import {AppState} from '../../store/app.state';

// export const selectProducts = (state: AppState) => state.products;
