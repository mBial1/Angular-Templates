import {filter} from 'rxjs/operators';
import {RouterLink} from '@angular/router';
import {Component, Input} from '@angular/core';
import {Router, NavigationEnd} from '@angular/router';
import {Location, CommonModule} from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  private previousUrl: string = '';

  @Input() title: string = '';
  @Input() user: boolean = false;
  @Input() showCard: boolean = false;
  @Input() showGoBack: Boolean = false;
  @Input() showDocument: boolean = false;
  @Input() showUserButton: boolean = false;

  constructor(private location: Location, private router: Router) {}

  ngOnInit(): void {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.previousUrl = event.url;
      });
  }

  goBack(): void {
    this.location.back();
  }

  canGoBack(): boolean {
    return this.previousUrl !== this.location.path();
  }
}
