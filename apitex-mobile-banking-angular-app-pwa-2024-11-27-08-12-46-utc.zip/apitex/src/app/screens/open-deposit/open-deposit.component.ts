import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';
import {ButtonComponent} from '../../components/button/button.component';
import {SwitcherComponent} from '../../components/switcher/switcher.component';

@Component({
  selector: 'app-open-deposit',
  standalone: true,
  imports: [
    HeaderComponent,
    CommonModule,
    InputFieldComponent,
    ButtonComponent,
    SwitcherComponent,
  ],
  templateUrl: './open-deposit.component.html',
  styleUrl: './open-deposit.component.scss',
})
export class OpenDepositComponent {
  constructor(private metaService: Meta) {}

  currencies = [
    {
      id: 1,
      name: 'USD',
    },
    {
      id: 2,
      name: 'EUR',
    },
  ];

  periods = [
    {
      id: 1,
      name: '3 mos',
    },
    {
      id: 2,
      name: '12 mos',
    },
    {
      id: 3,
      name: '24 mos',
    },
    {
      id: 4,
      name: '6 mos',
    },
    {
      id: 5,
      name: '18 mos',
    },
    {
      id: 6,
      name: '36 mos',
    },
  ];

  cards = [
    {
      id: 1,
      name: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27',
      icon: '/assets/cards/01.jpg',
    },
    {
      id: 2,
      name: 'Mastercard',
      number: '**** **** **** 7896',
      balance: '4 863.27',
      icon: '/assets/cards/02.jpg',
    },
  ];

  earlyDepositWithdrawal = true;
  selectedCard = this.cards[0].number;
  selectedPeriod = this.periods[0].name;
  selectedCurrency = this.currencies[0].name;

  setCurrency(currency: string) {
    this.selectedCurrency = currency;
  }

  setPeriod(period: string) {
    this.selectedPeriod = period;
  }

  setCard(card: string) {
    this.selectedCard = card;
  }

  setEarlyDepositWithdrawal() {
    this.earlyDepositWithdrawal = !this.earlyDepositWithdrawal;
  }

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
