import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';
import {RadioButtonComponent} from '../../components/radio-button/radio-button.component';
import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-open-moneybox',
  standalone: true,
  imports: [
    HeaderComponent,
    InputFieldComponent,
    CommonModule,
    RadioButtonComponent,
    ButtonComponent,
  ],
  templateUrl: './open-moneybox.component.html',
  styleUrl: './open-moneybox.component.scss',
})
export class OpenMoneyboxComponent {
  constructor(private metaService: Meta) {}

  cards = [
    {
      id: 1,
      name: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27',
      icon: '/assets/cards/01.jpg',
    },
    {
      id: 2,
      name: 'Mastercard',
      number: '**** **** **** 7896',
      balance: '4 863.27',
      icon: '/assets/cards/02.jpg',
    },
  ];

  options = [
    'Amount per day',
    'Rounding up to $1 per transaction',
    'Rounding up to $10 per transaction.',
  ];

  selectedOption = this.options[0];
  selectedCard = this.cards[0].number;

  setCard(card: any) {
    this.selectedCard = card.number;
  }

  setOption(option: string) {
    this.selectedOption = option;
  }

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
