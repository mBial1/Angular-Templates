import {RouterLink} from '@angular/router';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';
import {Component, OnInit} from '@angular/core';

import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';

@Component({
  selector: 'app-sign-in',
  standalone: true,
  imports: [
    HeaderComponent,
    InputFieldComponent,
    ButtonComponent,
    RouterLink,
    CommonModule,
  ],
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.scss',
})
export class SignInComponent implements OnInit {
  rememberMe: boolean = false;

  constructor(private metaService: Meta) {}

  toggleRememberMe(): void {
    this.rememberMe = !this.rememberMe;
  }

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
