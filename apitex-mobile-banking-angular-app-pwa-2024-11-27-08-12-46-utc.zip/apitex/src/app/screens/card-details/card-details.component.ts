import {Component} from '@angular/core';
import {RouterLink} from '@angular/router';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {SwitcherComponent} from '../../components/switcher/switcher.component';

@Component({
  selector: 'app-card-details',
  standalone: true,
  imports: [HeaderComponent, CommonModule, SwitcherComponent, RouterLink],
  templateUrl: './card-details.component.html',
  styleUrl: './card-details.component.scss',
})
export class CardDetailsComponent {
  isDefaultCard = true;

  limits = [
    {
      id: 1,
      title: 'Online payments',
      limit: 100,
      currency: 'USD',
      icon: '/assets/svg/globe.svg',
      route: '/payments',
    },
    {
      id: 2,
      title: 'ATM withdrawals',
      limit: 3000,
      currency: 'USD',
      icon: '/assets/svg/dollar-sign-card.svg',
      route: '',
    },
  ];

  security = [
    {
      id: 1,
      title: 'Change PIN code',
      icon: '/assets/svg/key-security.svg',
      route: '/change-pin-code',
    },
    {
      id: 2,
      title: 'Reissue the card',
      icon: '/assets/svg/refresh-cw.svg',
      route: '',
    },
    {
      id: 3,
      title: 'Block the card',
      icon: '/assets/svg/lock-security.svg',
      route: '',
    },
    {
      id: 4,
      title: 'Сlose the card',
      icon: '/assets/svg/trash.svg',
      route: '',
    },
  ];

  constructor(private metaService: Meta) {}

  ngOnInit() {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }

  setDefaultCard() {
    this.isDefaultCard = true;
  }
}
