import {Component} from '@angular/core';
import {Location} from '@angular/common';
import {RouterLink} from '@angular/router';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-card-menu',
  standalone: true,
  imports: [HeaderComponent, ButtonComponent, RouterLink],
  templateUrl: './card-menu.component.html',
  styleUrl: './card-menu.component.scss',
})
export class CardMenuComponent {
  constructor(private metaService: Meta, private location: Location) {}

  ngOnInit() {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }

  goBack(): void {
    this.location.back();
  }
}
