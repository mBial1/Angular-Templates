import {Component} from '@angular/core';
import {RouterLink} from '@angular/router';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';

import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';

@Component({
  selector: 'app-iban-payment',
  standalone: true,
  imports: [
    HeaderComponent,
    InputFieldComponent,
    ButtonComponent,
    RouterLink,
    CommonModule,
  ],
  templateUrl: './iban-payment.component.html',
  styleUrl: './iban-payment.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class IbanPaymentComponent {
  cards = [
    {
      id: 1,
      title: 'Visa',
      balance: '4 863.27',
      number: '**** **** **** 7895',
      image: '/assets/cards/01.jpg',
    },
    {
      id: 2,
      title: 'Mastercard',
      balance: '1 234.56',
      number: '**** **** **** 1234',
      image: '/assets/cards/02.jpg',
    },
  ];

  selectedCard: number | null = null;

  constructor(private metaService: Meta) {}

  selectCard(id: number): void {
    this.selectedCard = id;
  }

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
