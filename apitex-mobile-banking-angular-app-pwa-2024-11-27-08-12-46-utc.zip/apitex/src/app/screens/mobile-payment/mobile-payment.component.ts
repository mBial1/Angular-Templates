import {Component} from '@angular/core';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';

@Component({
  selector: 'app-mobile-payment',
  standalone: true,
  imports: [HeaderComponent, ButtonComponent, InputFieldComponent],
  templateUrl: './mobile-payment.component.html',
  styleUrl: './mobile-payment.component.scss',
})
export class MobilePaymentComponent {
  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
