import {Component} from '@angular/core';
import {Meta} from '@angular/platform-browser';

import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-invoice-sent',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './invoice-sent.component.html',
  styleUrl: './invoice-sent.component.scss',
})
export class InvoiceSentComponent {
  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
