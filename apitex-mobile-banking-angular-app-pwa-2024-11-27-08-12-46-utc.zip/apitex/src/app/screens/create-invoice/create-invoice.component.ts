import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';
import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-create-invoice',
  standalone: true,
  imports: [
    HeaderComponent,
    InputFieldComponent,
    ButtonComponent,
    CommonModule,
  ],
  templateUrl: './create-invoice.component.html',
  styleUrl: './create-invoice.component.scss',
})
export class CreateInvoiceComponent {
  constructor(private metaService: Meta) {}

  ngOnInit() {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }

  currency = 'USD';

  changeCurrency(currency: string) {
    this.currency = currency;
  }
}
