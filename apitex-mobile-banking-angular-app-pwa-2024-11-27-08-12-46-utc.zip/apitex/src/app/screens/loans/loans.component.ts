import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';
import {FooterComponent} from '../../components/footer/footer.component';

@Component({
  selector: 'app-loans',
  standalone: true,
  imports: [HeaderComponent, ButtonComponent, CommonModule, FooterComponent],
  templateUrl: './loans.component.html',
  styleUrl: './loans.component.scss',
})
export class LoansComponent {
  constructor(private metaService: Meta) {}

  loans = [
    {
      id: 1,
      rate: '13%',
      amount: '1 200.00',
      period: '24',
      monthlyPayment: '1 117.00',
      totalPaid: '26 808.00',
      leftToClose: '20 532.00',
    },
  ];

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
