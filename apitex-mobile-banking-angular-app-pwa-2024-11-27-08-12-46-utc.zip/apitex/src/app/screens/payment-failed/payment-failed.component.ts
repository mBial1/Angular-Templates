import {Component} from '@angular/core';
import {Meta} from '@angular/platform-browser';

import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-payment-failed',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './payment-failed.component.html',
  styleUrl: './payment-failed.component.scss',
})
export class PaymentFailedComponent {
  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
