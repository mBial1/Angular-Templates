import {Component} from '@angular/core';
import {RouterLink} from '@angular/router';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {FooterComponent} from '../../components/footer/footer.component';
import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-deposits',
  standalone: true,
  imports: [
    FooterComponent,
    HeaderComponent,
    CommonModule,
    ButtonComponent,
    RouterLink,
  ],
  templateUrl: './deposits.component.html',
  styleUrl: './deposits.component.scss',
})
export class DepositsComponent {
  deposits = [
    {
      id: 1,
      amount: '1 712.78',
      option: 'Withdrawal →',
      date: 'Jan 1 - Apr 1, 2023',
      icon: '/assets/svg/deposit-check.svg',
      route: '',
    },
    {
      id: 2,
      amount: '3 648.37',
      option: 'Top - up  →',
      date: 'Feb 1 - May 1, 2023',
      icon: '/assets/svg/deposit-8.svg',
      route: '/top-up-payment',
    },
  ];

  moneyBoxes = [
    {
      id: 1,
      amount: '650.37',
      name: 'Piggy Bank',
      goal: '1 200 USD',
      for: 'New iPhone Pro Max',
      icon: '/assets/svg/piggy.svg',
    },
  ];

  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
