import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {CardType} from '../../models/card.model';
import {HeaderComponent} from '../../components/header/header.component';
import {ButtonComponent} from '../../components/button/button.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';

@Component({
  selector: 'app-fund-transfer',
  standalone: true,
  imports: [
    HeaderComponent,
    CommonModule,
    InputFieldComponent,
    ButtonComponent,
  ],
  templateUrl: './fund-transfer.component.html',
  styleUrl: './fund-transfer.component.scss',
})
export class FundTransferComponent {
  cards = [
    {
      id: 1,
      type: 'Visa',
      balance: '4 863.27',
      number: '**** **** **** 7895',
      image: '/assets/cards/01.jpg',
    },
    {
      id: 2,
      type: 'Mastercard',
      balance: '1 234.56',
      number: '**** **** **** 1234',
      image: '/assets/cards/02.jpg',
    },
  ];

  activeCard = this.cards[0];

  setActiveCard(card: CardType) {
    this.activeCard = card;
  }

  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
