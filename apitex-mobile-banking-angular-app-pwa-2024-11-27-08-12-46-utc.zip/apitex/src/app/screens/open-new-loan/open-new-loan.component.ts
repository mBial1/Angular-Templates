import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {InputFieldComponent} from '../../components/input-field/input-field.component';
import {SwitcherComponent} from '../../components/switcher/switcher.component';
import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-open-new-loan',
  standalone: true,
  imports: [
    HeaderComponent,
    CommonModule,
    InputFieldComponent,
    SwitcherComponent,
    ButtonComponent,
  ],
  templateUrl: './open-new-loan.component.html',
  styleUrl: './open-new-loan.component.scss',
})
export class OpenNewLoanComponent {
  constructor(private metaService: Meta) {}

  currency = 'USD';
  periods = [
    {
      id: 1,
      name: '3 mos',
    },
    {
      id: 2,
      name: '12 mos',
    },
    {
      id: 3,
      name: '24 mos',
    },
    {
      id: 4,
      name: '6 mos',
    },
    {
      id: 5,
      name: '18 mos',
    },
    {
      id: 6,
      name: '36 mos',
    },
  ];

  selectedPeriod = this.periods[0].name;

  setCurrency(currency: string) {
    this.currency = currency;
  }

  setPeriod(period: string) {
    this.selectedPeriod = period;
  }

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
