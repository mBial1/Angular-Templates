import {Component} from '@angular/core';
import {Meta} from '@angular/platform-browser';

import {ButtonComponent} from '../../components/button/button.component';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './payment-success.component.html',
  styleUrl: './payment-success.component.scss',
})
export class PaymentSuccessComponent {
  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
