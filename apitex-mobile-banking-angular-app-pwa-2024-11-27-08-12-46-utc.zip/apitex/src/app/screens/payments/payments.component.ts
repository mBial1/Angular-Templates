import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterLink} from '@angular/router';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [HeaderComponent, CommonModule, RouterLink],
  templateUrl: './payments.component.html',
  styleUrl: './payments.component.scss',
})
export class PaymentsComponent {
  payments = [
    {
      id: 1,
      title: 'Money transfer',
      icon: '/assets/svg/money-exchange.svg',
      route: '/fund-transfer',
    },
    {
      id: 2,
      title: 'Mobile payment',
      icon: '/assets/svg/mobile-payment.svg',
      route: '/mobile-payment',
    },
    {
      id: 3,
      title: 'IBAN payment',
      icon: '/assets/svg/paycheck.svg',
      route: '/iban-payment',
    },
    {
      id: 4,
      title: 'Utility bills',
      icon: '/assets/svg/invoice.svg',
      route: '',
    },
    {
      id: 5,
      title: 'Transport',
      icon: '/assets/svg/insurance.svg',
    },
    {
      id: 6,
      title: 'Insurance',
      icon: '/assets/svg/insurance.svg',
    },
    {
      id: 7,
      title: 'Penalties',
      icon: '/assets/svg/yellow-card.svg',
    },
    {
      id: 8,
      title: 'charity',
      icon: '/assets/svg/charity.svg',
    },
  ];

  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
