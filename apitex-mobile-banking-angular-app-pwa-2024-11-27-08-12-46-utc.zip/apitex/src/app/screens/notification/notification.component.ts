import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';

import {HeaderComponent} from '../../components/header/header.component';
import {FooterComponent} from '../../components/footer/footer.component';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [HeaderComponent, FooterComponent, CommonModule],
  templateUrl: './notification.component.html',
  styleUrl: './notification.component.scss',
})
export class NotificationComponent {
  constructor(private metaService: Meta) {}

  notifications = [
    {
      id: 1,
      title: 'Your loan application has been approved!',
      date: 'Apr 12, 2023 at 12:47 PM',
      icon: '/assets/svg/notification-check.svg',
    },
    {
      id: 2,
      title: 'Your loan application was rejected!',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      date: 'Apr 12, 2023 at 12:47 PM',
      icon: '/assets/svg/alert.svg',
    },
    {
      id: 3,
      title: 'The loan repayment period expires!',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      date: 'Apr 12, 2023 at 12:47 PM',
      icon: '/assets/svg/rejected.svg',
    },
    {
      id: 4,
      title: 'Your piggy bank is full!',
      date: 'Apr 12, 2023 at 12:47 PM',
      icon: '/assets/svg/notification-check.svg',
    },
  ];

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }
}
