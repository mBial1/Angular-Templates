import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Meta} from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';

import {HeaderComponent} from '../../components/header/header.component';

@Component({
  selector: 'app-open-new-card',
  standalone: true,
  imports: [HeaderComponent, CommonModule],
  templateUrl: './open-new-card.component.html',
  styleUrl: './open-new-card.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class OpenNewCardComponent {
  type: string = 'Debet';
  currency: string = 'USD';
  paymentSystem: string = 'VISA';

  cards = [
    {
      id: 1,
      card: '/assets/cards/03.png',
    },
    {
      id: 2,
      card: '/assets/cards/04.png',
    },
  ];

  constructor(private metaService: Meta) {}

  ngOnInit(): void {
    this.metaService.updateTag({name: 'theme-color', content: '#fff'});
    window.scrollTo(0, 0);
  }

  setType(type: string) {
    this.type = type;
  }

  setCurrency(currency: string) {
    this.currency = currency;
  }

  setPaymentSystem(paymentSystem: string) {
    this.paymentSystem = paymentSystem;
  }
}
