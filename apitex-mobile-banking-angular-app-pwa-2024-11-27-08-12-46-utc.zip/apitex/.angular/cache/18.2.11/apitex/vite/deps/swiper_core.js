import {
  Swiper
} from "./chunk-33WJL5PK.js";
import "./chunk-2YKHTQQ7.js";
import "./chunk-4ULMLRGT.js";
export {
  Swiper,
  Swiper as default
};
//# sourceMappingURL=swiper_core.js.map
