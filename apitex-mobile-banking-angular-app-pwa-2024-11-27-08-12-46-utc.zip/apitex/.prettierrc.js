module.exports = {
  bracketSpacing: false,
  jsxBracketSameLine: false,
};
